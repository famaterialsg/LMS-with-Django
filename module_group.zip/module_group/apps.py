from django.apps import AppConfig


class ModuleGroupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'module_group'
